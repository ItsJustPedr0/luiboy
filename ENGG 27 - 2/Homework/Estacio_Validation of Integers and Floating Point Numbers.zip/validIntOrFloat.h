// Estacio, Peter Julius M. 
// ENGG 151.01 - A
// Project 1: Normalized Crosscorrelation
// validIntOrFloat.h

#ifndef validIntOrFloat
#define validIntOrFloat

#include <string>
#include <iostream>
#include <sstream>

using namespace std;

bool is_int(string s, int* value = 0);
bool is_floating_pt(string s, double* value = 0);

#endif
