// Peter Julius M. Estacio
// ENGG 27.01
// Project 1: Smallest and Largest Numbers
// main.cpp

#include "smallestAndLargest.cpp"

int main()
{
  double largestNumber = computeLargestNumber();
  std::cout << "The largest positive number stored in a double is: "
  << largestNumber << std::endl;

  double smallestNumber = computeSmallestNumber();
  std::cout << "The smallest positive number stored in a double is: "
  << smallestNumber << std::endl;
}